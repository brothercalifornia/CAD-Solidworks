# Privacy Policy

Tangix Design & Development AB, M&ouml;rbydalen 15, 182 52 Danderyd, Suecia (en adelante &rdquo;Tangix&rdquo;) procesa datos personales (como se describe a continuaci&oacute;n) de las personas que utilizan y navegan por este sitio web (el &rdquo;Sitio&rdquo;) y acceden a los servicios de Certificaci&oacute;n de SolidWorks, quien act&uacute;a &uacute;nicamente como Procesador en nombre de Dassault Syst&egrave;mes, una &laquo; soci&eacute;t&eacute; europ&eacute;enne &raquo; francesa, inscrita en el Registro Mercantil y de Sociedad de Versailles con su principal domicilio social en 10 rue Marcel Dassault 78140 V&eacute;lizy-Villacoublay, Francia, as&iacute; como sus Afiliados.

En virtud de la legislaci&oacute;n de Suecia y de la Uni&oacute;n Europea, y de com&uacute;n acuerdo con Dassault Syst&egrave;mes, Tangix se limita a procesar datos personales para los cuales Dassault Syst&egrave;mes es el Controlador de acuerdo con las instrucciones de Dassault Syst&egrave;mes.

## 1. &Aacute;MBITO DE APLICACI&Oacute;N DE ESTA POL&Iacute;TICA DE PRIVACIDAD

La presente Pol&iacute;tica de Privacidad establece los principios y las directrices que rigen la protecci&oacute;n de los Datos Personales (como se describen a continuaci&oacute;n) recopilados en o a trav&eacute;s del Sitio y relativos a los visitantes y usuarios del Sitio (&rdquo;Usted&rdquo; o &rdquo;Su&rdquo;).

Por Datos Personales (&rdquo;Datos Personales&rdquo;) se entiende cualquier informaci&oacute;n que pueda dar lugar a la identificaci&oacute;n de una persona. Por Datos No personales se entiende cualquier informaci&oacute;n que no pueda dar lugar a la identificaci&oacute;n de una persona.

El uso del Sitio y del servicio de Certificaci&oacute;n de SolidWorks se rige por los T&eacute;rminos de Uso de SolidWorks de la unidad de negocios de Dassault Syst&egrave;mes, que se pueden consultar en http://www.solidworks.com/sw/termsofuse.html. El uso del Sitio y los Datos Personales que proporcione en el Sitio est&aacute;n sujetos a los t&eacute;rminos de esta Pol&iacute;tica de Privacidad, as&iacute; como a los T&eacute;rminos de Uso de SolidWorks y su Pol&iacute;tica de Privacidad, disponibles en http://www.solidworks.com/sw/privacypolicy.htm

## 2. DATOS RECOPILADOS

A fin de utilizar ciertas funciones y caracter&iacute;sticas del Sitio, SolidWorks requiere que usted proporcione ciertos Datos Personales al visitar o usar el Sitio.

Para obtener informaci&oacute;n sobre los Datos Personales que el Sitio puede procesar, consulte la Pol&iacute;tica de privacidad de SolidWorks.

## 3. COOKIES

Las cookies son archivos de texto que se almacenan y utilizan para registrar informaci&oacute;n no personal y personal relacionada con su navegaci&oacute;n por el Sitio. El Sitio puede utilizar cookies u otras tecnolog&iacute;as que pueden recopilar o almacenar Datos Personales para mejorar los servicios para usted, por ejemplo:

- permitiendo que un servicio identifique su dispositivo para que no tenga que proporcionar la misma informaci&oacute;n varias veces;
- detectando que usted puede haber proporcionado ya un nombre de usuario y una contrase&ntilde;a para que no tenga que hacerlo repetidamente;
- contando cu&aacute;ntas personas utilizan los servicios, de modo que se pueda facilitar su uso y haya suficiente capacidad para asegurar que son r&aacute;pidos;
- analizando los datos para ayudar a Tangix a comprender la manera en que las personas interact&uacute;an con el Sitio y, a su vez, mejorar el Sitio.

El Sitio tambi&eacute;n puede utilizar terceros proveedores para medir y analizar la efectividad del Sitio. En tal caso, se pueden utilizar y almacenar balizas web y cookies proporcionadas por dichos terceros proveedores.

El Sitio instala cookies en nombre de LinkedIn.

El Sitio puede utilizar dos tipos de cookies: permanentes y temporales.

- Las cookies temporales desaparecen en cuanto se cierra la sesi&oacute;n en el Sitio.
- Las cookies permanentes permanecen despu&eacute;s de cerrar la sesi&oacute;n del Sitio para que se puedan utilizar en visitas posteriores al Sitio.

El Sitio le notificar&aacute; la primera vez que reciba una cookie y, a continuaci&oacute;n, usted decidir&aacute; si la acepta o la rechaza. Habida cuenta de lo anterior, al continuar utilizando el Sitio, usted autoriza expresamente al Sitio a utilizar dichas cookies.

Tambi&eacute;n puede configurar el software de su navegador para rechazar todas las cookies. Sin embargo, si lo hace, es posible que ciertas &aacute;reas y caracter&iacute;sticas del Sitio no funcionen correctamente y/o usted no pueda acceder a algunas partes o servicios del Sitio.

## 4. ENLACES A SITIOS WEB NO CONTROLADOS POR SOLIDWORKS

Este Sitio puede ofrecer enlaces a sitios web de terceros que pueden ser de su inter&eacute;s.

Para obtener informaci&oacute;n sobre la manera en que SolidWorks comparte los datos personales con dichos terceros, consulte la Pol&iacute;tica de Privacidad de SolidWorks.

## 5. TRANSMISI&Oacute;N DE DATOS PERSONALES

Si usted accede al Sitio desde una ubicaci&oacute;n fuera de los Estados Unidos, tenga en cuenta que a trav&eacute;s del uso continuado del Sitio, puede transferir sus Datos Personales a los Estados Unidos u otras jurisdicciones distintas a la suya. Para obtener informaci&oacute;n sobre la manera en que SolidWorks regula dichas transferencias, consulte la Pol&iacute;tica de Privacidad de SolidWorks.

## 6. DERECHO DE ACCESO A Y RECTIFICACI&Oacute;N DE LOS DATOS

Para obtener informaci&oacute;n sobre la manera en que SolidWorks regula su derecho de acceso a y rectificaci&oacute;n de sus Datos Personales, consulte la Pol&iacute;tica de Privacidad de SolidWorks.

## 7. SEGURIDAD DE LOS DATOS

Consulte la Pol&iacute;tica de Privacidad de SolidWorks para obtener informaci&oacute;n sobre la manera en que SolidWorks se compromete a garantizar la protecci&oacute;n y la seguridad de los Datos Personales que usted elija comunicar, a fin de garantizar la confidencialidad de sus Datos Personales y evitar que estos se falseen, da&ntilde;en, destruyan o revelen a partes no autorizadas.

## 8. RESOLUCI&Oacute;N DE CONTROVERSIAS

Si bien Tangix ha establecido salvaguardias razonables para proteger los Datos Personales, admitimos que no existe ning&uacute;n m&eacute;todo de transmisi&oacute;n o almacenamiento de Datos Personales que sea totalmente seguro.

No obstante, Tangix se compromete a garantizar la privacidad de los Datos Personales: si tiene motivos para creer que la seguridad de sus Datos Personales se ha visto comprometida o se ha utilizado indebidamente, le rogamos que se ponga en contacto con Solidworks mediante correo electr&oacute;nico a privacy@solidworks.com.

SolidWorks investigar&aacute; e intentar&aacute; resolver las reclamaciones relacionadas con el uso y la divulgaci&oacute;n de Datos Personales de acuerdo con los principios que figuran en esta Pol&iacute;tica de Privacidad.

## 9. CONTACTO

Para cualquier otra pregunta relacionada con la presente Pol&iacute;tica de Privacidad, puede enviar un correo electr&oacute;nico a info@tangix.com.

## 10. FECHA DE APLICACI&Oacute;N DE LA POL&Iacute;TICA DE PRIVACIDAD Y SUS MODIFICACIONES

La presente Pol&iacute;tica de Privacidad se puede actualizar de acuerdo con los requisitos y las circunstancias de Tangix, o cuando las leyes y las regulaciones vigentes as&iacute; lo exijan.
