# Privacy Policy

Tangix Design & Development AB, M&ouml;rbydalen 15, 182 52 Danderyd, Sweden (hereinafter &rdquo;Tangix&rdquo;) processes Personal Data (as defined below) of people using this software, browsing the associated websites in the virtualtester.com domain (the &rdquo;Site&rdquo;) and accessing the Certification service, solely acting as a Processor on behalf of Dassault Syst&egrave;mes, a French &laquo; soci&eacute;t&eacute; europ&eacute;enne &raquo;, registered in the Trade and Companies Register of Versailles and with its principal place of business at 10 rue Marcel Dassault 78140 V&eacute;lizy-Villacoublay, France, and its Affiliates.

In accordance with Swedish and European Union law, and by agreement with Dassault Syst&egrave;mes, Tangix is restricted to only process personal data for which Dassault Syst&egrave;mes is the Controller in accordance with Dassault Syst&egrave;mes instructions.

## 1. SCOPE OF THIS PRIVACY POLICY
This Privacy Policy sets forth the principles and guidelines governing the protection of the Personal Data (as defined below) collected on or through the Site and concerning the Site&rsquo;s visitors and users ("You" or "Your").

Personal data ("Personal Data") means any information that may result in the identification of an individual. Non-Personal Data means any information that does not result in the identification of an Individual.

Your use of the Site and any Personal Data You provide on the Site are subject to the terms of this Privacy Policy as well as Privacy Policy of Dassault Syst&egrave;mes, available at https://www.3ds.com/privacy-policy/

## 2. DATA COLLECTED
In order to use certain functions and features of the Site, it is required that You provide certain Personal Data when visiting or using the Site.

For information on which Personal Data the Site may process, please refer to the Privacy Policy of Dassault Syst&egrave;mes.

## 3. COOKIES
Cookies are text files stored and used to record non-personal and personal information concerning Your browsing of the Site. The Site may use cookies or other technologies which may collect or store Personal Data to improve services for you through, for example:

- enabling a service to recognize your device so you don&rsquo;t have to give the same information several times,
- recognizing that you may already have given a username and password so you don&rsquo;t need to do so repeatedly,
- measuring how many people are using services, so they can be made easier to use and there&rsquo;s enough capacity to ensure they are fast,
- analyzing data to help Tangix understand how people interact with the Site so Tangix can improve the Site.

The Site may also use third party vendors to measure and analyze the effectiveness of the Site. In such a case, web beacons and cookies provided by such third party vendors may be used and stored.
The Site sets cookies on behalf of LinkedIn.
The Site may use two types of cookies: permanent cookies and temporary cookies.

- Temporary cookies disappear as soon as you log off from the Site.
- Permanent cookies remain after logging off from the Site in order to be used on subsequent visits to the Site.

The Site will notify you the first time you receive a cookie, and then you decide whether to accept it or refuse it. By continuing to use the Site in consideration of the above, you expressly authorize the Site to use such cookies.
You can also configure your browser software to refuse all cookies; if you do so, however, some areas and features of the Site may not function properly and/or you may not access some parts or services of the Site.

## 4. LINKS TO THIRD PARTY WEBSITES
This Site might offer links to third party Websites which may be of interest to You.

For information on how Personal Data is shared with these third parties, please refer to the Privacy Policy of Dassault Syst&egrave;mes.

## 5. LOCATION OF PERSONAL DATA
Personal Data collected by Tangix to provide this service is stored on servers located in Frankfurt, Germany.

## 6. RIGHT OF ACCESS TO AND RECTIFICATION OF THE DATA
For information on how Your right of access to and rectification of Your Personal Data, please refer to the Privacy Policy of Dassault Syst&egrave;mes.

## 7. DATA SECURITY 
For information on how protection and security of your Personal Data is ensured please refer to the Privacy Policy of Dassault Syst&egrave;mes.

Tangix stores data on servers protected by firewalls and strong encryption. Access to the data for administration is limited and protected using two-factor authentication measures.
 
## 8. CONTACT
For any additional question concerning this Privacy Policy, You may send an email to info@tangix.com.
For questions concerning Privacy Policy of Dassault Syst&egrave;mes please see https://www.3ds.com/privacy-policy/

## 9. TANGIX' DATA PROTECTION OFFICER
Tangix' DPO is Mattias SANDSTR&Ouml;M who can be reached at info@tangix.com.

## 10. DATE OF ENTRY INTO FORCE OF THE PRIVACY POLICY AND CHANGES TO IT
This Privacy Policy may be updated according to Tangix requirements and circumstances, or when required by applicable laws and regulations.

Revised: May 20, 2018.
