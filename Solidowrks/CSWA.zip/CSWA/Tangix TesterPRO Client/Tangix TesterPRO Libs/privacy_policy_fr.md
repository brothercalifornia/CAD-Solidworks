# Privacy Policy

Tangix Design & Development AB, M&ouml;rbydalen 15, 182 52 Danderyd, Su&egrave;de (ci-apr&egrave;s &laquo; Tangix &raquo;) traite les Donn&eacute;es personnelles (telles que d&eacute;finies ci-dessous) des personnes qui utilisent et naviguent sur ce site Web (le &laquo; Site &raquo;) et qui acc&egrave;dent au service de certification SolidWorks agissant en tant que Sous-traitant pour le compte de Dassault Syst&egrave;mes, une &laquo; soci&eacute;t&eacute; europ&eacute;enne &raquo; fran&ccedil;aise, immatricul&eacute;e au registre du commerce et des soci&eacute;t&eacute;s de Versailles dont le si&egrave;ge principal est &agrave; 10 rue Marcel Dassault 78140 V&eacute;lizy-Villacoublay, en France, et ses Affili&eacute;s.

Conform&eacute;ment &agrave; la l&eacute;gislation su&eacute;doise et au droit de l'Union europ&eacute;enne, et apr&egrave;s accord avec Dassault Syst&egrave;mes, Tangix se limite &agrave; traiter uniquement les donn&eacute;es personnelles pour lesquelles Dassault Syst&egrave;mes est le contr&ocirc;leur et ce conform&eacute;ment aux instructions de Dassault Syst&egrave;mes.

## 1. CHAMP D'APPLICATION DE CETTE POLITIQUE DE CONFIDENTIALIT&Eacute;

Cette politique de confidentialit&eacute; &eacute;nonce les principes et les lignes directrices r&eacute;gissant la protection des donn&eacute;es personnelles (telles que d&eacute;finies ci-dessous) collect&eacute;es sur ou &agrave; travers le Site et concernant les visiteurs et les utilisateurs du Site (&laquo; Vous &raquo; ou &laquo; Votre &raquo;).

Les donn&eacute;es personnelles (&laquo; Donn&eacute;es Personnelles &raquo;) d&eacute;signent toute information pouvant entra&icirc;ner l'identification d'un individu. Les donn&eacute;es non personnelles signifient toute information qui n'entra&icirc;ne pas l'identification d'un individu.

L'utilisation du Site et du service de certification SolidWorks est r&eacute;gie par les conditions d'utilisation de SolidWorks des unit&eacute;s d'affaires de Dassault Syst&egrave;mes, qui se trouvent &agrave; l'adresse http://www.solidworks.com/sw/termsofuse.html. Votre utilisation du Site et les donn&eacute;es personnelles que vous fournissez sur le Site sont assujetties aux termes de cette politique de confidentialit&eacute; ainsi qu'aux conditions d'utilisation de SolidWorks et &agrave; sa politique de confidentialit&eacute;, disponibles &agrave; l'adresse : http://www.solidworks.com/sw/privacypolicy .htm

## 2. DONN&Eacute;ES COLLECT&Eacute;ES

Pour utiliser certaines fonctions et caract&eacute;ristiques du site, SolidWorks exige que vous fournissiez certaines donn&eacute;es personnelles lors de la visite ou de l'utilisation du Site.

Pour plus d'informations sur les donn&eacute;es personnelles que le Site peut traiter, veuillez consulter la politique de confidentialit&eacute; de SolidWorks.

## 3. COOKIES

Les cookies sont des fichiers texte stock&eacute;s et utilis&eacute;s pour enregistrer les donn&eacute;es personnelles et non personnelles concernant votre navigation sur le Site. Le Site peut utiliser des cookies ou d'autres technologies qui peuvent recueillir ou stocker des donn&eacute;es personnelles pour am&eacute;liorer vos services, par exemple :

- Permettre &agrave; un service de reconna&icirc;tre votre appareil afin que vous ne donniez pas les m&ecirc;mes informations &agrave; plusieurs reprises.
- Reconna&icirc;tre que vous avez peut-&ecirc;tre d&eacute;j&agrave; fourni un nom d'utilisateur et un mot de passe, donc vous n'avez pas besoin de le faire &agrave; plusieurs reprises.
- Mesurer le nombre de personnes qui utilisent les services, afin d&rsquo;am&eacute;liorer leur qualit&eacute; et faire en sorte qu'il y ait suffisamment de capacit&eacute; pour s'assurer de leur rapidit&eacute;.
- Analyser les donn&eacute;es pour aider Tangix &agrave; comprendre la fa&ccedil;on dont les gens interagissent avec le Site pour pouvoir l&rsquo;am&eacute;liorer &eacute;ventuellement.

Le Site peut &eacute;galement avoir recours aux fournisseurs tiers pour &eacute;valuer et analyser son efficacit&eacute;. Dans ce cas, les balises web et les cookies fournis par ces fournisseurs tiers peuvent &ecirc;tre utilis&eacute;s et stock&eacute;s.

Le Site d&eacute;finit les cookies au nom de LinkedIn.

Le Site peut utiliser deux types de cookies : cookies permanents et cookies temporaires.

- Les cookies temporaires disparaissent d&egrave;s que vous vous d&eacute;connectez du Site.
- Les cookies permanents restent apr&egrave;s la d&eacute;connexion du Site afin d'&ecirc;tre utilis&eacute;s lors des visites ult&eacute;rieures du m&ecirc;me Site.

Le Site vous avisera la premi&egrave;re fois que vous recevrez un cookie, puis vous d&eacute;ciderez de l'accepter ou de le refuser. En continuant d'utiliser le Site en tenant compte de ce qui pr&eacute;c&egrave;de, vous autorisez express&eacute;ment le Site &agrave; utiliser ces cookies.

Vous pouvez &eacute;galement configurer votre navigateur pour refuser tous les cookies; Si vous le faites, cependant, certains domaines et caract&eacute;ristiques du Site risquent de ne pas fonctionner correctement et / ou vous ne pouvez pas acc&eacute;der &agrave; certaines parties ou services du Site.

## 4. LIENS AUX SITES WEB NON CONTR&Ocirc;L&Eacute;S PAR SOLIDWORKS

Ce site pourrait offrir des liens vers des sites Web tiers qui pourraient vous int&eacute;resser.

Pour plus d'informations sur la fa&ccedil;on dont SolidWorks partage des donn&eacute;es personnelles avec ces tiers, veuillez consulter la politique de confidentialit&eacute; de SolidWorks.

## 5. TRANSFERT DE DONN&Eacute;ES PERSONNELLES

Si vous acc&eacute;dez au Site &agrave; partir d'un lieu situ&eacute; en dehors des &Eacute;tats-Unis, veuillez noter que, gr&acirc;ce &agrave; votre utilisation continue du Site, vous pouvez transf&eacute;rer vos donn&eacute;es personnelles aux &Eacute;tats-Unis ou &agrave; d'autres juridictions autres que les v&ocirc;tres. Pour plus d'informations sur la fa&ccedil;on dont SolidWorks r&eacute;gule ces transferts, veuillez consulter la politique de confidentialit&eacute; de SolidWorks.

## 6.  DROIT D'ACC&Egrave;S ET RECTIFICATION DES DONN&Eacute;ES

Pour plus d'informations sur la fa&ccedil;on dont SolidWorks r&egrave;gle votre droit d'acc&egrave;s et la rectification de vos donn&eacute;es personnelles, veuillez consulter la politique de confidentialit&eacute; de SolidWorks.

## 7. S&Eacute;CURIT&Eacute; DES DONN&Eacute;ES

Pour plus d'informations sur la fa&ccedil;on dont SolidWorks s'engage &agrave; assurer la protection et la s&eacute;curit&eacute; des donn&eacute;es personnelles que vous choisissez de communiquer, afin d'assurer la confidentialit&eacute; de vos donn&eacute;es personnelles et de les emp&ecirc;cher d'&ecirc;tre d&eacute;form&eacute;es, endommag&eacute;es, d&eacute;truites ou divulgu&eacute;es &agrave; des parties non autoris&eacute;es, veuillez consulter la politique de confidentialit&eacute; de SolidWorks.

## 8. R&Egrave;GLEMENT DES DIFF&Eacute;RENDS

Bien que Tangix ait mis en place des garanties raisonnables pour prot&eacute;ger les donn&eacute;es personnelles, nous reconnaissons qu'il n'existe pas de m&eacute;thode de transmission ou de stockage de donn&eacute;es personnelles de fa&ccedil;on enti&egrave;rement s&eacute;curitaire.

Cependant, Tangix s'est engag&eacute; &agrave; assurer la confidentialit&eacute; des donn&eacute;es personnelles : si vous avez une raison de croire que la s&eacute;curit&eacute; de vos donn&eacute;es personnelles a &eacute;t&eacute; compromise ou mal utilis&eacute;e, vous devez contacter Solidworks en envoyant un e-mail &agrave; privacy@solidworks.com.

SolidWorks &eacute;tudiera et tentera de r&eacute;soudre les plaintes concernant l'utilisation et la divulgation des donn&eacute;es personnelles conform&eacute;ment aux principes contenus dans cette politique de confidentialit&eacute;.

## 9. CONTACT

Pour toute question suppl&eacute;mentaire concernant cette politique de confidentialit&eacute;, vous pouvez envoyer un e-mail &agrave; info@tangix.com.

##. 10 DATE D'ENTR&Eacute;E EN VIGUEUR DE LA POLITIQUE DE CONFIDENTIALIT&Eacute; ET SES MODIFICATIONS

Cette politique de confidentialit&eacute; peut &ecirc;tre mise &agrave; jour selon les exigences et les circonstances de Tangix, ou lorsque les lois et r&egrave;glements applicables l'exigent.

Revised: June 1st, 2017
