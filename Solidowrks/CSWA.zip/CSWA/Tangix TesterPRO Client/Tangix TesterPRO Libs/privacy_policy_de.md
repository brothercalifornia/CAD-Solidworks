# Privacy Policy

Tangix Design & Development AB, M&ouml;rbydalen 15, 182 52 Danderyd, Schweden (nachfolgend &bdquo;Tangix&ldquo;) verarbeitet pers&ouml;nliche Daten (wie nachstehend definiert) von Personen, die diese Website (die &bdquo;Seite&ldquo;) nutzen und auf den SolidWorks-Zertifizierungsdienst zugreifen. Tangix handelt dabei ausschlie&szlig;lich als Datenverarbeitungsdienstleister im Auftrag von Dassault Syst&egrave;mes, einer franz&ouml;sischen &laquo;Soci&eacute;t&eacute; Europ&eacute;enne&raquo;, eingetragen im Handels- und Gesellschaftsregister von Versailles und mit Hauptsitz in 10 Rue Marcel Dassault 78140 V&eacute;lizy-Villacoublay, Frankreich, und ihren verbundenen Unternehmen. 

Im Einklang mit schwedischem und dem Recht der Europ&auml;ischen Union sowie nach Vereinbarung mit Dassault Syst&egrave;mes beschr&auml;nkt Tangix sich darauf, nur pers&ouml;nliche Daten zu verarbeiten, f&uuml;r die Dassault Syst&egrave;mes die kontrollierende Instanz gem&auml;&szlig; den Anweisungen von Dassault Syst&egrave;mes ist. 

## 1. UMFANG DIESER DATENSCHUTZRICHTLINIE

Diese Datenschutzrichtlinie enth&auml;lt die Grunds&auml;tze und Richtlinien f&uuml;r den Schutz der pers&ouml;nlichen Daten (wie nachstehend definiert), die auf der oder &uuml;ber die Seite erhoben werden und die Besucher und Nutzer der Seite (&bdquo;Sie&ldquo; oder &bdquo;Ihr&ldquo;) betreffen. 

Pers&ouml;nliche Daten (&bdquo;Pers&ouml;nliche Daten&ldquo;) sind alle Informationen, die zur Identifizierung einer Person f&uuml;hren k&ouml;nnen. Nicht-pers&ouml;nliche Daten sind alle Informationen, die nicht zur Identifizierung einer Person f&uuml;hren. 

Die Nutzung der Seite und des SolidWorks-Zertifizierungsdienstes unterliegen den Nutzungsbedingungen der Gesch&auml;ftseinheit SolidWorks von Dassault Syst&egrave;mes, die Sie hier einsehen k&ouml;nnen: http://www.solidworks.com/sw/termsofuse.html. Ihre Nutzung der Seite und alle pers&ouml;nliche Daten, die Sie dieser zur Verf&uuml;gung stellen, unterliegen den Bestimmungen dieser Datenschutzrichtlinie sowie den Nutzungsbedingungen von SolidWorks und deren Datenschutzrichtlinie unter http://www.solidworks.com/sw/ Privacypolicy.htm.

## 2. DATENERHEBUNG

Um bestimmte Funktionen und Funktionalit&auml;ten der Seite nutzen zu k&ouml;nnen, verlangt SolidWorks, dass Sie bestimmte pers&ouml;nliche Daten beim Besuch oder bei der Nutzung der Website angeben. 

F&uuml;r Informationen dar&uuml;ber, welche pers&ouml;nlichen Daten die Seite verarbeiten kann, verweisen wir auf die SolidWorks Datenschutzrichtlinien. 

## 3. COOKIES

Cookies sind Textdateien, die gespeichert und verwendet werden, um nicht-pers&ouml;nliche und pers&ouml;nliche Informationen &uuml;ber Ihr Surfverhalten auf der Seite zu erfassen. Die Seite kann Cookies oder andere Technologien verwenden, die pers&ouml;nliche Daten sammeln oder speichern k&ouml;nnen, um den Service f&uuml;r Sie zu verbessern, zum Beispiel f&uuml;r Folgendes: 

- Zur Erm&ouml;glichung einer Funktion, die es erlaubt, Ihr Ger&auml;t zu erkennen, sodass Sie gleichen Informationen nicht mehrmals eingeben m&uuml;ssen.
- Zur Erkennung, dass Sie bereits einen Benutzernamen und ein Passwort angegeben haben, sodass Sie dies nicht wiederholt tun m&uuml;ssen.
- Zum Messen, wie viele Menschen bestimmte Dienste nutzen, sodass sie einfacher zu bedienen sind und um sicherzustellen, dass genug Kapazit&auml;ten f&uuml;r schnelles Surfen vorhanden sind.
- Zur Analyse von Daten, damit Tangix verstehen kann, wie Menschen mit der Seite interagieren, und basierend auf diesen Informationen die Website verbessern kann. 

Die Seite kann auch mit Drittanbietern, zur Messung der Wirksamkeit der Seite und zur Analyse, arbeiten. In einem solchen Fall k&ouml;nnen Web-Beacons und Cookies, die von Drittanbietern zur Verf&uuml;gung gestellt werden, verwendet und gespeichert werden. 

Die Seite setzt Cookies im Namen von LinkedIn.

Die Seite kann zwei Arten von Cookies verwenden: permanente Cookies und tempor&auml;re Cookies. 

- Tempor&auml;re Cookies verschwinden, sobald Sie sich von der Seite abmelden. 
- Permanente Cookies bleiben nach der Abmeldung von der Seite auf Ihrem Computer, um bei sp&auml;teren Besuchen auf der Seite wiederverwendet zu werden. 

Die Seite benachrichtigt Sie beim ersten Mal, wenn ein Cookie gesetzt wird, und dann entscheiden Sie, ob Sie ihn akzeptieren oder verweigern. Durch die fortgesetzte Nutzung der Seite unter Ber&uuml;cksichtigung des oben Genannten erlauben Sie ausdr&uuml;cklich das Setzen von solchen Cookies. 

Sie k&ouml;nnen auch Ihre Browser-Software so konfigurieren, alle Cookies abzulehnen. Wenn Sie dies tun, k&ouml;nnten jedoch einige Bereiche und Funktionen der Seite nicht ordnungsgem&auml;&szlig; funktionieren und/oder Sie k&ouml;nnten auf einige Teile oder Dienste der Seite nicht zugreifen. 

## 4. LINKS ZU WEBSEITEN, DIE NICHT VON SOLIDWORKS KONTROLLIERT WERDEN

Diese Seite bietet Links zu Webseiten Dritter an, die f&uuml;r Sie von Interesse sein k&ouml;nnten.

Informationen dar&uuml;ber, wie SolidWorks pers&ouml;nliche Daten mit diesen Dritten teilt, finden Sie in der Datenschutzrichtlinie von SolidWorks. 

## 5. &Uuml;BERTRAGUNG VON PERS&Ouml;NLICHEN DATEN

Wenn Sie auf die Seite von einem Ort au&szlig;erhalb der Vereinigten Staaten zugreifen, beachten Sie bitte, dass Sie durch Ihre fortgesetzte Nutzung der Seite Ihre pers&ouml;nlichen Daten an die Vereinigten Staaten oder in andere L&auml;nder als Ihr eigenes &uuml;bertragen k&ouml;nnen. Informationen dar&uuml;ber, wie SolidWorks solche &Uuml;bertragungen regelt, finden Sie in der SolidWorks Datenschutzrichtlinie. 

## 6. RECHT AUF ZUGANG UND BERICHTIGUNG DER DATEN

Informationen dar&uuml;ber, wie SolidWorks Ihr Recht auf Zugang und Berichtigung Ihrer pers&ouml;nlichen Daten regelt, finden Sie in der Datenschutzrichtlinie von SolidWorks. 

## 7. DATENSICHERHEIT

Informationen dar&uuml;ber, wie sich SolidWorks verpflichtet, den Schutz und die Sicherheit der von Ihnen &uuml;bermittelten pers&ouml;nlichen Daten zu gew&auml;hrleisten, die Vertraulichkeit Ihrer pers&ouml;nlichen Daten zu sichern und Ihre pers&ouml;nlichen Daten davor zu sch&uuml;tzen, verzerrt, besch&auml;digt, zerst&ouml;rt oder an Unbefugte weitergegeben zu werden, finden Sie in der SolidWorks Datenschutzrichtlinie. 

## 8. BEILEGUNG VON DISPUTEN

Obwohl Tangix angemessene Schutzma&szlig;nahmen zum Schutz pers&ouml;nlichen Daten implementiert hat, wissen wir, dass es keine Methode zur &Uuml;bermittlung oder Speicherung von personenbezogenen Daten gibt, die vollst&auml;ndig sicher ist. 

Allerdings hat sich Tangix verpflichtet, die Privatsph&auml;re der pers&ouml;nlichen Daten zu gew&auml;hrleisten: Wenn Sie einen Grund zu der Annahme haben, dass die Sicherheit Ihrer pers&ouml;nlichen Daten kompromittiert wurde oder Daten zweckentfremdet wurden, kontaktieren Sie bitte Solidworks, indem Sie eine E-Mail an privacy@solidworks.com senden. 

SolidWorks wird eine Untersuchung einleiten und versuchen, Beschwerden &uuml;ber die Verwendung und Offenlegung von pers&ouml;nlichen Daten gem&auml;&szlig; den in dieser Datenschutzrichtlinie enthaltenen Grunds&auml;tzen zu kl&auml;ren. 

## 9. KONTAKT

Falls Sie weitere Fragen zu dieser Datenschutzrichtlinie haben, schicken Sie bitte eine E-Mail an info@tangix.com 

## 10. DATUM DES INKRAFTTRETENS DER DATENSCHUTZRICHTLINIE UND IHRER &Auml;NDERUNGEN 

Diese Datenschutzrichtlinie kann von Tangix nach deren Bedarf oder den Umst&auml;nden entsprechend oder nach geltenden Gesetzen und Bestimmungen aktualisiert werden.

Revised: June 1st, 2016